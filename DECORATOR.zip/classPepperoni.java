public class Pepperoni extends Ingredienteadd {

    private $sanduiche
    public function __construct(Sanduiche $sanduiche) {
        $this -> sanduiche = $sanduiche;

    }
    public function getNome(){
        return $this -> sanduiche -> getNome(). "Pepperoni";
    }

    public function valor(); {
        return 0,99 $this->sanduiche->valor();
    
}
