public abstract class Ingredienteadd {

    protected $nome;

    public function getNome(){
        return $this -> nome ;
    }
}
