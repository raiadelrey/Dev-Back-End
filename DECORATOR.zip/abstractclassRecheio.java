public abstract class Recheio extends Sanduiche {
    protected $nome;

    public function getNome(){
        return $this -> nome ;
    }
    public function valor();

    
}
